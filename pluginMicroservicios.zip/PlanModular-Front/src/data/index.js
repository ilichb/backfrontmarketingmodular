export {sectorComercialArray} from './sector-comercial.js';
export {countryArray} from './countries.js';
export {servicesArray} from './services';